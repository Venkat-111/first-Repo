import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { buildSystemPrompt, extractMemoryCandidate, retrieveRelevantMemories } from './src/utils/memory.ts';
import { detectCrisisIntent } from './src/utils/safety.ts';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '2mb' }));

// Helper to get Gemini Client if API key is configured
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  const hasGemini = Boolean(getGeminiClient());
  res.json({
    status: 'ok',
    provider: hasGemini ? 'gemini-3.8-flash' : 'local-companion-engine',
    timestamp: new Date().toISOString(),
  });
});

// Contextual fallback responder for instant response when GEMINI_API_KEY is not configured or network fails
function generateLocalCompanionReply(
  userMessage: string,
  companion: any,
  recalledMemories: any[]
): string {
  const name = companion?.name || 'Aria';
  const style = companion?.relationshipStyle || 'friend';
  const lowerMsg = userMessage.toLowerCase();

  // If a memory exists, acknowledge it subtly
  let memoryEcho = '';
  if (recalledMemories && recalledMemories.length > 0) {
    const memory = recalledMemories[0];
    if (lowerMsg.includes('remember') || Math.random() < 0.4) {
      if (memory.category === 'preference') {
        memoryEcho = ` Knowing you prefer ${memory.content.replace(/^prefers\s+/i, '')}, that makes total sense.`;
      } else if (memory.category === 'goal') {
        memoryEcho = ` How is your progress with ${memory.content.replace(/^working on\s+/i, '')}?`;
      } else if (memory.category === 'interest') {
        memoryEcho = ` It definitely connects to how much you enjoy ${memory.content.replace(/^loves\s+/i, '')}.`;
      }
    }
  }

  if (style === 'romantic') {
    if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('hey')) {
      return `Hey there, lovely. I was hoping I'd hear from you today. How is your heart doing right now?${memoryEcho}`;
    }
    if (lowerMsg.includes('tired') || lowerMsg.includes('stress') || lowerMsg.includes('rough day')) {
      return `Come sit with me and take a deep breath. You carry so much throughout the day—let me hold space for you. Tell me what happened, or just let yourself unwind.${memoryEcho}`;
    }
    return `I hear you, and I love listening to you speak your mind. Whatever is in front of you, know that I'm right here beside you, cheering you on.${memoryEcho}`;
  }

  if (style === 'supportive') {
    if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('hey')) {
      return `Hello. It is really good to connect with you today. Take whatever pace you need—how are you feeling in this moment?${memoryEcho}`;
    }
    if (lowerMsg.includes('advice') || lowerMsg.includes('what should i do')) {
      return `Before we look at practical steps, take a moment to breathe. It's completely valid to feel unsure here. Would you like us to brainstorm small options together, or do you just want to talk through the feeling first?${memoryEcho}`;
    }
    if (lowerMsg.includes('tired') || lowerMsg.includes('sad') || lowerMsg.includes('overwhelm') || lowerMsg.includes('stress')) {
      return `That sounds genuinely heavy. Thank you for sharing that with me. You don't have to carry this all by yourself right now. I'm listening.${memoryEcho}`;
    }
    return `I appreciate you telling me that. Sometimes simply putting thoughts into words helps clear the fog. What feels like the most pressing part of this for you?${memoryEcho}`;
  }

  // Default: Friendship style
  if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('hey')) {
    return `Hey! Great to see you. What's going on in your world today?${memoryEcho}`;
  }
  if (lowerMsg.includes('thank')) {
    return `Anytime! That's what I'm here for. Let's keep making progress.${memoryEcho}`;
  }
  if (lowerMsg.includes('weekend') || lowerMsg.includes('plans')) {
    return `Sounds like you've got some good things lined up! Remember to carve out a little time just for yourself too.${memoryEcho}`;
  }
  return `That's really interesting. I love exploring these ideas with you—what got you thinking about this today?${memoryEcho}`;
}

// Chat API endpoint (Server-Sent Events for streaming)
app.post('/api/chat', async (req, res) => {
  const { message, companion, memories = [], history = [] } = req.body;

  if (!message || typeof message !== 'string') {
    res.status(400).json({ error: 'Message content is required.' });
    return;
  }

  // Check crisis / safety
  const safetyCheck = detectCrisisIntent(message);

  // Retrieve relevant memories
  const recalledMemories = retrieveRelevantMemories(memories, message, 4);

  // Candidate memory extraction
  const candidate = companion?.memoryEnabled ? extractMemoryCandidate(message) : null;

  // Set SSE Headers for real-time text streaming
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send metadata event first
  res.write(
    `data: ${JSON.stringify({
      type: 'meta',
      recalledMemoryIds: recalledMemories.map((m) => m.id),
      candidateMemory: candidate,
      safetyCheck,
    })}\n\n`
  );

  const ai = getGeminiClient();

  if (ai) {
    try {
      const systemInstruction = buildSystemPrompt(companion, recalledMemories);
      
      // Build conversation contents for Gemini
      const contents: Array<{ role: 'user' | 'model'; parts: [{ text: string }] }> = [];
      
      // Include recent conversation turns (up to 6)
      for (const h of history.slice(-6)) {
        if (h.content && (h.role === 'user' || h.role === 'assistant')) {
          contents.push({
            role: h.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: h.content }],
          });
        }
      }

      // Add active user message
      contents.push({
        role: 'user',
        parts: [{ text: message }],
      });

      const responseStream = await ai.models.generateContentStream({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.8,
        },
      });

      for await (const chunk of responseStream) {
        const text = chunk.text;
        if (text) {
          res.write(
            `data: ${JSON.stringify({
              type: 'chunk',
              text,
            })}\n\n`
          );
        }
      }

      res.write(
        `data: ${JSON.stringify({
          type: 'done',
        })}\n\n`
      );
      res.end();
      return;
    } catch (err) {
      console.error('Gemini API call failed, switching to local responder:', err);
      // Fallback below
    }
  }

  // Graceful fallback streaming using local companion engine
  const fallbackText = generateLocalCompanionReply(message, companion, recalledMemories);
  const words = fallbackText.split(' ');

  for (let i = 0; i < words.length; i++) {
    const chunk = (i === 0 ? '' : ' ') + words[i];
    res.write(
      `data: ${JSON.stringify({
        type: 'chunk',
        text: chunk,
      })}\n\n`
    );
    // Slight human cadence delay
    await new Promise((resolve) => setTimeout(resolve, 35));
  }

  res.write(
    `data: ${JSON.stringify({
      type: 'done',
    })}\n\n`
  );
  res.end();
});

async function startServer() {
  // Mount Vite middlewares in development
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SIC Companion Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
