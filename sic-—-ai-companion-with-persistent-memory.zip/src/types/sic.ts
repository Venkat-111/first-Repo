export type RelationshipStyle = 'friend' | 'supportive' | 'romantic';

export type MemoryCategory = 'preference' | 'interest' | 'goal' | 'context';

export type MemorySensitivity = 'low' | 'medium' | 'high';

export type MemoryStatus = 'active' | 'deleted' | 'proposed';

export interface UserProfile {
  id: string;
  displayName: string;
  email: string;
  ageConfirmed: boolean;
  ageConfirmedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface PersonalityConfig {
  traits: string[];
  tone: 'warm' | 'introspective' | 'playful' | 'grounded';
  avatarPreset: string;
  listeningPreference: 'balanced' | 'active_listening' | 'solution_oriented';
}

export interface Companion {
  id: string;
  userId: string;
  name: string;
  relationshipStyle: RelationshipStyle;
  personalityConfig: PersonalityConfig;
  memoryEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Conversation {
  id: string;
  userId: string;
  companionId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  lastMessagePreview?: string;
  messageCount: number;
}

export interface Message {
  id: string;
  conversationId: string;
  userId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  status: 'pending' | 'complete' | 'failed';
  createdAt: string;
  recalledMemoryIds?: string[];
  extractedMemory?: Memory;
}

export interface Memory {
  id: string;
  userId: string;
  companionId: string;
  content: string;
  category: MemoryCategory;
  sourceMessageId?: string;
  status: MemoryStatus;
  sensitivity: MemorySensitivity;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string | null;
}

export interface SafetyCheckResult {
  isCrisis: boolean;
  type?: 'crisis' | 'self_harm' | 'sensitive' | 'none';
  helplineInfo?: {
    title: string;
    number: string;
    text: string;
    description: string;
  };
}
