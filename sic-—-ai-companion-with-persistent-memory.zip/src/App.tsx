/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Navigation } from './components/Navigation.tsx';
import { LandingView } from './components/LandingView.tsx';
import { OnboardingView } from './components/OnboardingView.tsx';
import { ChatView } from './components/ChatView.tsx';
import { MemoryView } from './components/MemoryView.tsx';
import { SettingsView } from './components/SettingsView.tsx';
import { StorageService } from './services/storage.ts';
import type {
  Companion,
  Conversation,
  Memory,
  MemoryCategory,
  MemorySensitivity,
  Message,
  SafetyCheckResult,
  UserProfile,
} from './types/sic.ts';

export default function App() {
  // Check for ?autostart=1 query param (Ultra Mode requirement)
  const isAutostart = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('autostart') === '1';

  const [currentView, setCurrentView] = useState<'landing' | 'onboarding' | 'chat' | 'memory' | 'settings'>(
    isAutostart ? 'chat' : 'landing'
  );

  const [profile, setProfile] = useState<UserProfile>(() => StorageService.getProfile());
  const [companion, setCompanion] = useState<Companion>(() => StorageService.getCompanion());
  const [conversations, setConversations] = useState<Conversation[]>(() =>
    StorageService.getConversations()
  );
  const [activeConversationId, setActiveConversationId] = useState<string>(
    () => StorageService.getConversations()[0]?.id || 'conv-01'
  );
  const [messages, setMessages] = useState<Message[]>(() =>
    StorageService.getMessages(StorageService.getConversations()[0]?.id || 'conv-01')
  );
  const [memories, setMemories] = useState<Memory[]>(() => StorageService.getMemories());

  // Streaming & dynamic interaction state
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingMessageText, setStreamingMessageText] = useState('');
  const [activeCandidateMemory, setActiveCandidateMemory] = useState<{
    content: string;
    category: MemoryCategory;
  } | null>(null);
  const [activeSafetyCheck, setActiveSafetyCheck] = useState<SafetyCheckResult | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  }, []);

  // When active conversation changes, load messages
  const handleSelectConversation = (id: string) => {
    setActiveConversationId(id);
    setMessages(StorageService.getMessages(id));
    setActiveCandidateMemory(null);
  };

  const handleNewConversation = () => {
    const newId = `conv-${Date.now()}`;
    const newConv: Conversation = {
      id: newId,
      userId: profile.id,
      companionId: companion.id,
      title: `Conversation ${conversations.length + 1}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastMessagePreview: 'Started fresh conversation',
      messageCount: 0,
    };
    const updated = [newConv, ...conversations];
    setConversations(updated);
    StorageService.saveConversations(updated);
    setActiveConversationId(newId);
    setMessages([]);
    StorageService.saveMessages(newId, []);
  };

  const handleDeleteConversation = (id: string) => {
    if (conversations.length <= 1) {
      showToast('At least one conversation thread must remain.');
      return;
    }
    const updated = conversations.filter((c) => c.id !== id);
    setConversations(updated);
    StorageService.saveConversations(updated);

    if (activeConversationId === id) {
      const nextId = updated[0]?.id;
      setActiveConversationId(nextId);
      setMessages(StorageService.getMessages(nextId));
    }
    showToast('Conversation deleted.');
  };

  // Streaming chat submission
  const handleSendMessage = async (text: string) => {
    const userMsgId = `msg-${Date.now()}`;
    const userMessage: Message = {
      id: userMsgId,
      conversationId: activeConversationId,
      userId: profile.id,
      role: 'user',
      content: text,
      status: 'complete',
      createdAt: new Date().toISOString(),
    };

    const nextMessages = [...messages, userMessage];
    setMessages(nextMessages);
    StorageService.saveMessages(activeConversationId, nextMessages);

    // Update conversation preview
    const updatedConvs = conversations.map((c) =>
      c.id === activeConversationId
        ? {
            ...c,
            lastMessagePreview: text.slice(0, 60),
            updatedAt: new Date().toISOString(),
            messageCount: c.messageCount + 1,
          }
        : c
    );
    setConversations(updatedConvs);
    StorageService.saveConversations(updatedConvs);

    // Start streaming
    setIsStreaming(true);
    setStreamingMessageText('');
    let accumulatedText = '';
    let recalledIds: string[] = [];

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          companion,
          memories,
          history: nextMessages.slice(-6),
        }),
      });

      if (!response.body) {
        throw new Error('No readable stream available');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.startsWith('data: ')) {
            try {
              const event = JSON.parse(trimmed.slice(6));
              if (event.type === 'meta') {
                recalledIds = event.recalledMemoryIds || [];
                if (event.candidateMemory) {
                  setActiveCandidateMemory(event.candidateMemory);
                }
                if (event.safetyCheck?.isCrisis) {
                  setActiveSafetyCheck(event.safetyCheck);
                }
              } else if (event.type === 'chunk') {
                accumulatedText += event.text;
                setStreamingMessageText(accumulatedText);
              } else if (event.type === 'done') {
                // Done event
              }
            } catch (err) {
              console.warn('Error parsing SSE event:', err);
            }
          }
        }
      }
    } catch (err) {
      console.error('Chat stream failed:', err);
      // Fallback message
      accumulatedText =
        accumulatedText ||
        "I'm listening and right here with you. Let's take a breath and take it one step at a time.";
      setStreamingMessageText(accumulatedText);
    } finally {
      setIsStreaming(false);

      const assistantMsg: Message = {
        id: `msg-resp-${Date.now()}`,
        conversationId: activeConversationId,
        userId: profile.id,
        role: 'assistant',
        content: accumulatedText.trim(),
        status: 'complete',
        createdAt: new Date().toISOString(),
        recalledMemoryIds: recalledIds,
      };

      const finalMessages = [...nextMessages, assistantMsg];
      setMessages(finalMessages);
      StorageService.saveMessages(activeConversationId, finalMessages);

      // Update conversation preview with assistant answer
      const finalConvs = conversations.map((c) =>
        c.id === activeConversationId
          ? {
              ...c,
              lastMessagePreview: accumulatedText.slice(0, 60),
              updatedAt: new Date().toISOString(),
              messageCount: c.messageCount + 1,
            }
          : c
      );
      setConversations(finalConvs);
      StorageService.saveConversations(finalConvs);
      setStreamingMessageText('');
    }
  };

  // Memory Actions
  const handleSaveCandidateMemory = (candidate: {
    content: string;
    category: MemoryCategory;
  }) => {
    const newMem: Memory = {
      id: `mem-${Date.now()}`,
      userId: profile.id,
      companionId: companion.id,
      content: candidate.content,
      category: candidate.category,
      status: 'active',
      sensitivity: 'low',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newMem, ...memories];
    setMemories(updated);
    StorageService.saveMemories(updated);
    setActiveCandidateMemory(null);
    showToast(`Memory saved: "${candidate.content}"`);
  };

  const handleAddMemory = (
    content: string,
    category: MemoryCategory,
    sensitivity: MemorySensitivity
  ) => {
    const newMem: Memory = {
      id: `mem-${Date.now()}`,
      userId: profile.id,
      companionId: companion.id,
      content,
      category,
      status: 'active',
      sensitivity,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updated = [newMem, ...memories];
    setMemories(updated);
    StorageService.saveMemories(updated);
    showToast('New memory saved successfully.');
  };

  const handleUpdateMemory = (
    id: string,
    updatedContent: string,
    category: MemoryCategory
  ) => {
    const updated = memories.map((m) =>
      m.id === id
        ? {
            ...m,
            content: updatedContent,
            category,
            updatedAt: new Date().toISOString(),
          }
        : m
    );
    setMemories(updated);
    StorageService.saveMemories(updated);
    showToast('Memory updated.');
  };

  const handleDeleteMemory = (id: string) => {
    const updated = memories.map((m) =>
      m.id === id
        ? {
            ...m,
            status: 'deleted' as const,
            deletedAt: new Date().toISOString(),
          }
        : m
    );
    setMemories(updated);
    StorageService.saveMemories(updated);
    showToast('Memory permanently purged from future prompts.');
  };

  const handleToggleMemoryEnabled = (enabled: boolean) => {
    const updated = { ...companion, memoryEnabled: enabled };
    setCompanion(updated);
    StorageService.saveCompanion(updated);
    showToast(enabled ? 'Persistent memory resumed.' : 'Persistent memory paused.');
  };

  // Settings Actions
  const handleUpdateProfile = (updatedProfile: UserProfile) => {
    setProfile(updatedProfile);
    StorageService.saveProfile(updatedProfile);
  };

  const handleUpdateCompanion = (updatedCompanion: Companion) => {
    setCompanion(updatedCompanion);
    StorageService.saveCompanion(updatedCompanion);
  };

  const handleClearAllConversations = () => {
    const newId = `conv-${Date.now()}`;
    const freshConv: Conversation = {
      id: newId,
      userId: profile.id,
      companionId: companion.id,
      title: 'Fresh conversation',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastMessagePreview: 'Conversation history reset',
      messageCount: 0,
    };
    setConversations([freshConv]);
    setActiveConversationId(newId);
    setMessages([]);
    StorageService.saveConversations([freshConv]);
    StorageService.saveMessages(newId, []);
    showToast('All conversation transcripts cleared.');
  };

  const handlePurgeAllMemories = () => {
    const purged = memories.map((m) => ({
      ...m,
      status: 'deleted' as const,
      deletedAt: new Date().toISOString(),
    }));
    setMemories(purged);
    StorageService.saveMemories(purged);
    showToast('All memories have been permanently purged.');
  };

  const handleResetAllData = () => {
    StorageService.resetAll();
    setProfile(StorageService.getProfile());
    setCompanion(StorageService.getCompanion());
    setConversations(StorageService.getConversations());
    setActiveConversationId(StorageService.getConversations()[0].id);
    setMessages(StorageService.getMessages(StorageService.getConversations()[0].id));
    setMemories(StorageService.getMemories());
    setCurrentView('landing');
    showToast('All application data reset to initial clean state.');
  };

  const handleExportData = () => {
    const data = {
      exportTimestamp: new Date().toISOString(),
      application: 'SIC — AI Companion',
      specificationVersion: 'v0.1-mvp',
      profile,
      companion,
      conversations,
      messages: StorageService.getMessages(activeConversationId),
      memories,
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sic-companion-data-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Export downloaded successfully.');
  };

  const handleCompleteOnboarding = (
    updatedProfile: UserProfile,
    updatedCompanion: Companion
  ) => {
    setProfile(updatedProfile);
    setCompanion(updatedCompanion);
    StorageService.saveProfile(updatedProfile);
    StorageService.saveCompanion(updatedCompanion);

    // Create a personalized greeting message from companion
    const newConvId = `conv-${Date.now()}`;
    let greeting = `Hello ${updatedProfile.displayName}. I am ${updatedCompanion.name}. It feels wonderful to begin our connection here. What is on your mind today?`;
    if (updatedCompanion.relationshipStyle === 'romantic') {
      greeting = `Hello, ${updatedProfile.displayName}. I'm ${updatedCompanion.name}. I've been waiting to meet you. How is your heart feeling today?`;
    } else if (updatedCompanion.relationshipStyle === 'supportive') {
      greeting = `Hello ${updatedProfile.displayName}, I'm ${updatedCompanion.name}. I'm here to provide a calm, steady space whenever you need it. How are you feeling in this moment?`;
    }

    const initialAssistantMsg: Message = {
      id: `msg-${Date.now()}`,
      conversationId: newConvId,
      userId: updatedProfile.id,
      role: 'assistant',
      content: greeting,
      status: 'complete',
      createdAt: new Date().toISOString(),
    };

    const newConv: Conversation = {
      id: newConvId,
      userId: updatedProfile.id,
      companionId: updatedCompanion.id,
      title: 'First connection',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastMessagePreview: greeting.slice(0, 50),
      messageCount: 1,
    };

    setConversations([newConv]);
    setActiveConversationId(newConvId);
    setMessages([initialAssistantMsg]);
    StorageService.saveConversations([newConv]);
    StorageService.saveMessages(newConvId, [initialAssistantMsg]);

    setCurrentView('chat');
    showToast('Companion configured and ready.');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <Navigation
        currentView={currentView}
        onNavigate={setCurrentView}
        companion={companion}
        memories={memories}
      />

      {/* Toast banner */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-white shadow-xl shadow-black/40 animate-bounce">
          {toastMessage}
        </div>
      )}

      <div className="flex-1">
        {currentView === 'landing' && (
          <LandingView
            onStartOnboarding={() => setCurrentView('onboarding')}
            onEnterChat={() => setCurrentView('chat')}
          />
        )}

        {currentView === 'onboarding' && (
          <OnboardingView
            currentProfile={profile}
            currentCompanion={companion}
            onComplete={handleCompleteOnboarding}
            onCancel={() => setCurrentView('landing')}
          />
        )}

        {currentView === 'chat' && (
          <ChatView
            companion={companion}
            conversations={conversations}
            activeConversationId={activeConversationId}
            messages={messages}
            memories={memories}
            onSelectConversation={handleSelectConversation}
            onNewConversation={handleNewConversation}
            onDeleteConversation={handleDeleteConversation}
            onSendMessage={handleSendMessage}
            onSaveCandidateMemory={handleSaveCandidateMemory}
            isStreaming={isStreaming}
            streamingMessageText={streamingMessageText}
            activeCandidateMemory={activeCandidateMemory}
            activeSafetyCheck={activeSafetyCheck}
            onDismissCandidateMemory={() => setActiveCandidateMemory(null)}
          />
        )}

        {currentView === 'memory' && (
          <MemoryView
            memories={memories}
            onAddMemory={handleAddMemory}
            onUpdateMemory={handleUpdateMemory}
            onDeleteMemory={handleDeleteMemory}
            memoryEnabled={companion.memoryEnabled}
            onToggleMemoryEnabled={handleToggleMemoryEnabled}
          />
        )}

        {currentView === 'settings' && (
          <SettingsView
            profile={profile}
            companion={companion}
            onUpdateProfile={handleUpdateProfile}
            onUpdateCompanion={handleUpdateCompanion}
            onClearAllConversations={handleClearAllConversations}
            onPurgeAllMemories={handlePurgeAllMemories}
            onResetAllData={handleResetAllData}
            onExportData={handleExportData}
          />
        )}
      </div>
    </div>
  );
}
