import React, { useState } from 'react';
import {
  ShieldAlert,
  Heart,
  Sparkles,
  Smile,
  Brain,
  Check,
  ArrowRight,
  UserCheck,
} from 'lucide-react';
import type { Companion, PersonalityConfig, RelationshipStyle, UserProfile } from '../types/sic.ts';

interface OnboardingViewProps {
  currentProfile: UserProfile;
  currentCompanion: Companion;
  onComplete: (updatedProfile: UserProfile, updatedCompanion: Companion) => void;
  onCancel: () => void;
}

export const OnboardingView: React.FC<OnboardingViewProps> = ({
  currentProfile,
  currentCompanion,
  onComplete,
  onCancel,
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Step 1: 18+ Confirmation & Display Name
  const [displayName, setDisplayName] = useState(currentProfile.displayName || 'Alex');
  const [ageConfirmed, setAgeConfirmed] = useState(currentProfile.ageConfirmed || false);
  const [privacyAgreed, setPrivacyAgreed] = useState(true);

  // Step 2: Relationship Style
  const [relationshipStyle, setRelationshipStyle] = useState<RelationshipStyle>(
    currentCompanion.relationshipStyle || 'supportive'
  );

  // Step 3: Companion Identity & Preferences
  const [companionName, setCompanionName] = useState(currentCompanion.name || 'Aria');
  const [tone, setTone] = useState<PersonalityConfig['tone']>(
    currentCompanion.personalityConfig?.tone || 'warm'
  );
  const [avatarPreset, setAvatarPreset] = useState(
    currentCompanion.personalityConfig?.avatarPreset || 'warm-ember'
  );
  const [selectedTraits, setSelectedTraits] = useState<string[]>(
    currentCompanion.personalityConfig?.traits || ['Empathetic', 'Thoughtful', 'Calm']
  );
  const [listeningPreference, setListeningPreference] = useState<
    PersonalityConfig['listeningPreference']
  >(currentCompanion.personalityConfig?.listeningPreference || 'active_listening');
  const [memoryEnabled, setMemoryEnabled] = useState(currentCompanion.memoryEnabled !== false);

  const availableTraits = [
    'Empathetic',
    'Thoughtful',
    'Witty',
    'Calm',
    'Grounded',
    'Playful',
    'Introspective',
    'Adventurous',
    'Direct',
  ];

  const avatarPresets = [
    { id: 'warm-ember', name: 'Warm Ember', bg: 'from-amber-600 to-rose-600', ring: 'ring-amber-500' },
    { id: 'deep-indigo', name: 'Deep Indigo', bg: 'from-indigo-600 to-blue-600', ring: 'ring-indigo-500' },
    { id: 'sage-moss', name: 'Sage Moss', bg: 'from-emerald-600 to-teal-700', ring: 'ring-emerald-500' },
    { id: 'rose-quartz', name: 'Rose Quartz', bg: 'from-pink-600 to-purple-600', ring: 'ring-pink-500' },
  ];

  const handleTraitToggle = (trait: string) => {
    if (selectedTraits.includes(trait)) {
      if (selectedTraits.length > 1) {
        setSelectedTraits(selectedTraits.filter((t) => t !== trait));
      }
    } else {
      if (selectedTraits.length < 4) {
        setSelectedTraits([...selectedTraits, trait]);
      }
    }
  };

  const handleFinish = () => {
    const updatedProfile: UserProfile = {
      ...currentProfile,
      displayName: displayName.trim() || 'Alex',
      ageConfirmed: true,
      ageConfirmedAt: currentProfile.ageConfirmedAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updatedCompanion: Companion = {
      ...currentCompanion,
      name: companionName.trim() || 'Aria',
      relationshipStyle,
      personalityConfig: {
        traits: selectedTraits,
        tone,
        avatarPreset,
        listeningPreference,
      },
      memoryEnabled,
      updatedAt: new Date().toISOString(),
    };

    onComplete(updatedProfile, updatedCompanion);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-10 sm:py-14">
      {/* Step Indicator */}
      <div className="flex items-center justify-between mb-8 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-mono uppercase tracking-wider text-indigo-400">
            Step {step} of 3
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">
            {step === 1 && 'Eligibility & Transparency'}
            {step === 2 && 'Choose Relationship Style'}
            {step === 3 && 'Design Your Companion'}
          </h2>
        </div>
        <div className="flex items-center gap-1.5">
          {[1, 2, 3].map((num) => (
            <div
              key={num}
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                step === num
                  ? 'bg-indigo-500 w-6'
                  : step > num
                  ? 'bg-emerald-400'
                  : 'bg-slate-800'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Step 1: Age Confirmation & Core Privacy */}
      {step === 1 && (
        <div className="space-y-6">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-sm text-slate-300 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-white">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Adults 18+ Experience & AI Disclosure</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              SIC is an artificial intelligence platform designed exclusively for adults aged 18 and older. SIC engages in conversations and saves memory context you approve, but it is not a human partner or a clinical mental health care provider.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Your Preferred Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="e.g. Alex"
              className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          <div className="space-y-3 pt-2">
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={ageConfirmed}
                onChange={(e) => setAgeConfirmed(e.target.checked)}
                className="mt-1 w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0 focus:ring-offset-0"
              />
              <span className="text-sm text-slate-200">
                I confirm that I am at least 18 years of age and eligible to use SIC.
              </span>
            </label>

            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={privacyAgreed}
                onChange={(e) => setPrivacyAgreed(e.target.checked)}
                className="mt-1 w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0 focus:ring-offset-0"
              />
              <span className="text-sm text-slate-200">
                I understand that SIC is an AI companion and that I retain 100% control to inspect and delete any saved memories.
              </span>
            </label>
          </div>

          <div className="pt-6 flex justify-end gap-3">
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-sm font-medium"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={!ageConfirmed || !privacyAgreed}
              onClick={() => setStep(2)}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white text-sm font-semibold transition-all flex items-center gap-2"
            >
              <span>Continue</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Relationship Style */}
      {step === 2 && (
        <div className="space-y-6">
          <p className="text-sm text-slate-300">
            How would you like your AI companion to relate to you? You can easily change this anytime in Settings.
          </p>

          <div className="space-y-3.5">
            {/* Friendship */}
            <div
              onClick={() => setRelationshipStyle('friend')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                relationshipStyle === 'friend'
                  ? 'bg-amber-950/20 border-amber-500/80 ring-1 ring-amber-500/40'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">Friendship</h4>
                    <p className="text-xs text-slate-400">Casual camaraderie, shared humor, and daily check-ins</p>
                  </div>
                </div>
                {relationshipStyle === 'friend' && <Check className="w-5 h-5 text-amber-400" />}
              </div>
            </div>

            {/* Supportive */}
            <div
              onClick={() => setRelationshipStyle('supportive')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                relationshipStyle === 'supportive'
                  ? 'bg-emerald-950/20 border-emerald-500/80 ring-1 ring-emerald-500/40'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                    <Heart className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">Emotional Support</h4>
                    <p className="text-xs text-slate-400">Active listening, validation, and gentle sounding-board</p>
                  </div>
                </div>
                {relationshipStyle === 'supportive' && <Check className="w-5 h-5 text-emerald-400" />}
              </div>
            </div>

            {/* Romantic */}
            <div
              onClick={() => setRelationshipStyle('romantic')}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                relationshipStyle === 'romantic'
                  ? 'bg-rose-950/20 border-rose-500/80 ring-1 ring-rose-500/40'
                  : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-rose-500/10 text-rose-400 flex items-center justify-center">
                    <Smile className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-white">Romantic</h4>
                    <p className="text-xs text-slate-400">Tender affection, thoughtful flirtation, and intimacy</p>
                  </div>
                </div>
                {relationshipStyle === 'romantic' && <Check className="w-5 h-5 text-rose-400" />}
              </div>
            </div>
          </div>

          <div className="pt-6 flex justify-between">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-sm font-medium"
            >
              Back
            </button>
            <button
              type="button"
              onClick={() => setStep(3)}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all flex items-center gap-2"
            >
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Companion Persona & Memory Consent */}
      {step === 3 && (
        <div className="space-y-6">
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Companion Name
            </label>
            <input
              type="text"
              value={companionName}
              onChange={(e) => setCompanionName(e.target.value)}
              placeholder="e.g. Aria, Julian, Kaia"
              className="w-full px-4 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Avatar Color Preset */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Companion Presence
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {avatarPresets.map((preset) => (
                <div
                  key={preset.id}
                  onClick={() => setAvatarPreset(preset.id)}
                  className={`p-3 rounded-xl border cursor-pointer flex flex-col items-center gap-2 text-center transition-all ${
                    avatarPreset === preset.id
                      ? 'bg-slate-800 border-indigo-500 ring-2 ring-indigo-500/30'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full bg-gradient-to-tr ${preset.bg}`} />
                  <span className="text-xs text-slate-300 font-medium">{preset.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tone */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Conversation Tone
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['warm', 'introspective', 'playful', 'grounded'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setTone(t)}
                  className={`py-2 px-3 rounded-lg text-xs font-medium capitalize border transition-all ${
                    tone === t
                      ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Traits */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Personality Traits (select up to 4)
            </label>
            <div className="flex flex-wrap gap-2">
              {availableTraits.map((trait) => {
                const selected = selectedTraits.includes(trait);
                return (
                  <button
                    key={trait}
                    type="button"
                    onClick={() => handleTraitToggle(trait)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                      selected
                        ? 'bg-violet-600/20 text-violet-300 border-violet-500'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    {trait}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Persistent Memory Consent */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-indigo-400" />
                <span className="text-sm font-semibold text-white">Enable Persistent Memory</span>
              </div>
              <input
                type="checkbox"
                checked={memoryEnabled}
                onChange={(e) => setMemoryEnabled(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-0 focus:ring-offset-0"
              />
            </div>
            <p className="text-xs text-slate-400">
              When enabled, SIC recalls your preferences and goals across sessions. You can inspect, edit, or delete any memory at any time in the Memories tab.
            </p>
          </div>

          <div className="pt-6 flex justify-between">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:bg-slate-800 text-sm font-medium"
            >
              Back
            </button>
            <button
              type="button"
              onClick={handleFinish}
              className="px-7 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-sm font-semibold transition-all shadow-md shadow-indigo-600/30 flex items-center gap-2"
            >
              <span>Begin Chatting</span>
              <Sparkles className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
