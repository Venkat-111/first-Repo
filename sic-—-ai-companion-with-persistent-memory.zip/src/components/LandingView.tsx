import React from 'react';
import {
  Sparkles,
  Shield,
  Brain,
  Heart,
  MessageCircle,
  Eye,
  Sliders,
  CheckCircle2,
  Lock,
  ArrowRight,
} from 'lucide-react';
import type { RelationshipStyle } from '../types/sic.ts';

interface LandingViewProps {
  onStartOnboarding: () => void;
  onEnterChat: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onStartOnboarding,
  onEnterChat,
}) => {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col justify-between">
      {/* Hero Section */}
      <section className="relative px-4 sm:px-6 pt-16 pb-20 max-w-5xl mx-auto text-center">
        {/* Glow backdrop */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-indigo-600/15 blur-[120px] rounded-full pointer-events-none" />

        {/* AI & Adult Transparency Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300 mb-8 shadow-inner">
          <span className="w-2 h-2 rounded-full bg-indigo-400 animate-ping" />
          <span className="font-semibold text-white">SIC Platform</span>
          <span className="text-slate-500">•</span>
          <span>18+ Adults Only</span>
          <span className="text-slate-500">•</span>
          <span className="text-indigo-400 font-mono">100% Transparent AI</span>
        </div>

        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white max-w-3xl mx-auto leading-tight sm:leading-none">
          An AI companion that remembers <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-300 to-amber-300">what matters.</span>
        </h1>

        <p className="mt-6 text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
          Choose a relationship style, engage in natural conversations, and develop genuine continuity through persistent, user-controlled memory.
        </p>

        {/* CTAs */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onStartOnboarding}
            className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-semibold text-base shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 group"
          >
            <span>Set Up Companion</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onEnterChat}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 font-medium text-base transition-all flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4 text-slate-400" />
            <span>Open Existing Session</span>
          </button>
        </div>

        {/* Clear Trust Statement */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Transparent AI persona
          </span>
          <span className="flex items-center gap-1.5">
            <Lock className="w-4 h-4 text-indigo-400" /> Inspect & delete any memory
          </span>
          <span className="flex items-center gap-1.5">
            <Shield className="w-4 h-4 text-amber-400" /> Zero sensitive data leakage
          </span>
        </div>
      </section>

      {/* 3 Relationship Styles Section */}
      <section className="px-4 sm:px-6 py-16 bg-slate-950 border-y border-slate-900">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-white">Your terms, your connection</h2>
            <p className="mt-2 text-slate-400 text-sm sm:text-base">
              Choose the emotional frequency that fits your life. Switch styles at any time in Settings.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Style 1: Friendship */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-amber-500/40 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Friendship</h3>
              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                Witty banter, everyday camaraderie, sounding-board discussions, and shared hobbies without romantic pressure.
              </p>
              <div className="text-xs text-amber-400/90 font-mono flex items-center gap-1.5">
                <span>Tone:</span> Playful, candid, loyal
              </div>
            </div>

            {/* Style 2: Emotional Support */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-emerald-500/40 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
                <Heart className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Emotional Support</h3>
              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                A non-judgmental sanctuary for decompressing, untangling stress, and gentle reflection with dedicated listening modes.
              </p>
              <div className="text-xs text-emerald-400/90 font-mono flex items-center gap-1.5">
                <span>Tone:</span> Empathetic, grounded, calm
              </div>
            </div>

            {/* Style 3: Romantic */}
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-rose-500/40 transition-all group">
              <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 flex items-center justify-center mb-5 group-hover:scale-105 transition-transform">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Romantic</h3>
              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                Affectionate check-ins, tender intimacy, and playful flirtation grounded in safety—never manipulative guilt or jealousy.
              </p>
              <div className="text-xs text-rose-400/90 font-mono flex items-center gap-1.5">
                <span>Tone:</span> Tender, attentive, warm
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Memory Differentiator Section */}
      <section className="px-4 sm:px-6 py-16 max-w-5xl mx-auto">
        <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-900/40 rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-300 text-xs font-semibold mb-4 border border-indigo-500/20">
                <Brain className="w-3.5 h-3.5" />
                Persistent, User-Governed Memory
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white leading-tight">
                Continuity without invasive surveillance.
              </h2>
              <p className="mt-4 text-slate-300 text-sm sm:text-base leading-relaxed">
                SIC remembers what matters to your conversations—your preferences, upcoming goals, and interests—without dumping whole chat transcripts or hoarding sensitive credentials.
              </p>
              <ul className="mt-6 space-y-3 text-sm text-slate-300">
                <li className="flex items-center gap-2.5">
                  <Eye className="w-4 h-4 text-violet-400" />
                  <span>Inspect every memory saved in readable language</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Sliders className="w-4 h-4 text-violet-400" />
                  <span>Edit wording or purge memories permanently</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Lock className="w-4 h-4 text-violet-400" />
                  <span>Passwords, medical secrets, and financial info are blocked</span>
                </li>
              </ul>
            </div>

            {/* Visual Memory Card Preview */}
            <div className="space-y-3 font-sans">
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80 shadow-xl">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span className="font-mono text-indigo-300 uppercase tracking-wider text-[10px]">
                    Goal • Medium sensitivity
                  </span>
                  <span>Saved 2 days ago</span>
                </div>
                <p className="text-slate-100 text-sm font-medium">
                  "Working on finishing personal design portfolio by end of month"
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-700/80 shadow-xl translate-x-2">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span className="font-mono text-emerald-300 uppercase tracking-wider text-[10px]">
                    Preference • Low sensitivity
                  </span>
                  <span>Active</span>
                </div>
                <p className="text-slate-100 text-sm font-medium">
                  "Prefers quiet mornings and drinking ceremonial matcha before work"
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900 px-4 sm:px-6 py-8 text-center text-xs text-slate-400">
        <p className="max-w-2xl mx-auto">
          SIC is an artificial intelligence product for adults aged 18 and older. It does not replace human relationships, medical advice, or professional crisis intervention.
        </p>
      </footer>
    </div>
  );
};
