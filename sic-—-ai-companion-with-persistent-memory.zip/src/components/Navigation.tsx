import React from 'react';
import { MessageSquare, Brain, Settings, ShieldCheck, Heart, Sparkles, UserCheck } from 'lucide-react';
import type { Companion, Memory } from '../types/sic.ts';

interface NavigationProps {
  currentView: 'landing' | 'onboarding' | 'chat' | 'memory' | 'settings';
  onNavigate: (view: 'landing' | 'onboarding' | 'chat' | 'memory' | 'settings') => void;
  companion: Companion;
  memories: Memory[];
}

export const Navigation: React.FC<NavigationProps> = ({
  currentView,
  onNavigate,
  companion,
  memories,
}) => {
  const activeMemoriesCount = memories.filter((m) => m.status === 'active' && !m.deletedAt).length;

  const relationshipColor =
    companion.relationshipStyle === 'romantic'
      ? 'text-rose-400 bg-rose-500/10 border-rose-500/30'
      : companion.relationshipStyle === 'supportive'
      ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
      : 'text-amber-400 bg-amber-500/10 border-amber-500/30';

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand / Logo */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => onNavigate('landing')}
            className="flex items-center gap-2.5 text-left group transition-all"
            aria-label="SIC Home"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-violet-600 to-amber-500 flex items-center justify-center shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-wider text-white">SIC</span>
                <span className="text-[10px] tracking-widest font-mono uppercase px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                  AI COMPANION
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Memory that matters</p>
            </div>
          </button>

          {/* Active Companion Indicator */}
          {currentView !== 'landing' && currentView !== 'onboarding' && (
            <div className="hidden md:flex items-center gap-2 pl-4 border-l border-slate-800 text-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-slate-200 font-semibold">{companion.name}</span>
              <span
                className={`text-[11px] capitalize px-2 py-0.5 rounded-full border font-medium ${relationshipColor}`}
              >
                {companion.relationshipStyle}
              </span>
            </div>
          )}
        </div>

        {/* View Switcher / Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2">
          {currentView !== 'landing' && currentView !== 'onboarding' ? (
            <>
              <button
                onClick={() => onNavigate('chat')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentView === 'chat'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
                aria-label="Open Chat view"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat</span>
              </button>

              <button
                onClick={() => onNavigate('memory')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium transition-colors relative ${
                  currentView === 'memory'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
                aria-label="Open Memories view"
              >
                <Brain className="w-4 h-4 text-violet-400" />
                <span>Memories</span>
                <span className="ml-1 text-[11px] px-1.5 py-0.2 rounded-full bg-violet-500/20 text-violet-300 font-mono">
                  {activeMemoriesCount}
                </span>
              </button>

              <button
                onClick={() => onNavigate('settings')}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentView === 'settings'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
                aria-label="Open Settings view"
              >
                <Settings className="w-4 h-4" />
                <span className="hidden sm:inline">Settings</span>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-3">
              <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Adults 18+ • Private by default
              </span>
              <button
                onClick={() => onNavigate('onboarding')}
                className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold transition-all shadow-md shadow-indigo-600/30 flex items-center gap-2"
              >
                <Heart className="w-4 h-4" />
                <span>Configure Companion</span>
              </button>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
};
