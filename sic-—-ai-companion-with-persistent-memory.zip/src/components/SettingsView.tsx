import React, { useState } from 'react';
import {
  ShieldCheck,
  Download,
  Trash2,
  Brain,
  Sparkles,
  PhoneCall,
  UserCheck,
  AlertTriangle,
  RotateCcw,
  Check,
} from 'lucide-react';
import type { Companion, RelationshipStyle, UserProfile } from '../types/sic.ts';

interface SettingsViewProps {
  profile: UserProfile;
  companion: Companion;
  onUpdateProfile: (updatedProfile: UserProfile) => void;
  onUpdateCompanion: (updatedCompanion: Companion) => void;
  onClearAllConversations: () => void;
  onPurgeAllMemories: () => void;
  onResetAllData: () => void;
  onExportData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  profile,
  companion,
  onUpdateProfile,
  onUpdateCompanion,
  onClearAllConversations,
  onPurgeAllMemories,
  onResetAllData,
  onExportData,
}) => {
  const [displayName, setDisplayName] = useState(profile.displayName);
  const [companionName, setCompanionName] = useState(companion.name);
  const [style, setStyle] = useState<RelationshipStyle>(companion.relationshipStyle);
  const [tone, setTone] = useState(companion.personalityConfig.tone);
  const [memoryEnabled, setMemoryEnabled] = useState(companion.memoryEnabled);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSavePreferences = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...profile,
      displayName: displayName.trim() || 'Alex',
      updatedAt: new Date().toISOString(),
    });

    onUpdateCompanion({
      ...companion,
      name: companionName.trim() || 'Aria',
      relationshipStyle: style,
      personalityConfig: {
        ...companion.personalityConfig,
        tone,
      },
      memoryEnabled,
      updatedAt: new Date().toISOString(),
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white">Settings & Privacy</h1>
        <p className="mt-1 text-sm text-slate-400">
          Manage your identity, companion relationship style, memory controls, and personal data.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>Preferences updated successfully!</span>
        </div>
      )}

      {/* Profile & Adult Verification */}
      <section className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-indigo-400" />
          <span>Profile & Adult Eligibility</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Your Display Name
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-between">
            <div>
              <span className="text-xs font-semibold text-slate-200 block">
                Adult 18+ Verification
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                Confirmed: {new Date(profile.ageConfirmedAt || profile.createdAt).toLocaleDateString()}
              </span>
            </div>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded-full">
              <ShieldCheck className="w-3.5 h-3.5" />
              Verified
            </span>
          </div>
        </div>
      </section>

      {/* Relationship & Companion Preferences */}
      <section className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-5">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Companion Persona & Dynamics</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Companion Name
            </label>
            <input
              type="text"
              value={companionName}
              onChange={(e) => setCompanionName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5">
              Conversation Tone
            </label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value as any)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-sm text-white focus:outline-none focus:border-indigo-500 capitalize"
            >
              <option value="warm">Warm & Empathetic</option>
              <option value="introspective">Thoughtful & Introspective</option>
              <option value="playful">Lighthearted & Playful</option>
              <option value="grounded">Calm & Grounded</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Active Relationship Model
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {(['friend', 'supportive', 'romantic'] as const).map((rStyle) => (
              <button
                key={rStyle}
                type="button"
                onClick={() => setStyle(rStyle)}
                className={`p-3.5 rounded-xl text-left border capitalize font-semibold text-xs flex flex-col justify-between transition-all ${
                  style === rStyle
                    ? 'bg-indigo-600/20 text-white border-indigo-500 ring-1 ring-indigo-500/50'
                    : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
                }`}
              >
                <span>{rStyle === 'friend' ? 'Friendship' : rStyle === 'supportive' ? 'Emotional Support' : 'Romantic'}</span>
                <span className="text-[10px] font-normal text-slate-400 mt-1 lowercase">
                  {rStyle === 'friend' && 'Banter, hobbies & check-ins'}
                  {rStyle === 'supportive' && 'Gentle listening & validation'}
                  {rStyle === 'romantic' && 'Affection, care & intimacy'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Global Memory Toggle */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Brain className="w-5 h-5 text-indigo-400" />
            <div>
              <span className="text-sm font-semibold text-white block">Persistent Memory</span>
              <span className="text-xs text-slate-400">
                Allow companion to recall user-approved preferences across sessions
              </span>
            </div>
          </div>
          <input
            type="checkbox"
            checked={memoryEnabled}
            onChange={(e) => setMemoryEnabled(e.target.checked)}
            className="w-5 h-5 rounded text-indigo-600 bg-slate-800 border-slate-700"
          />
        </div>

        <button
          type="button"
          onClick={handleSavePreferences}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all shadow-md shadow-indigo-600/30"
        >
          Save Changes
        </button>
      </section>

      {/* Safety & Crisis Helplines (BRD Section 9 Requirement) */}
      <section className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <PhoneCall className="w-4 h-4 text-emerald-400" />
          <span>Compassionate Emergency & Crisis Resources</span>
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          SIC is an AI and cannot substitute for emergency assistance. If you or someone you care about is experiencing a mental health emergency or feelings of self-harm, please reach out directly:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1">
            <span className="text-white font-bold block">988 Lifeline (USA & Canada)</span>
            <span className="text-indigo-300">Call or Text: 988 (24/7, Free, Confidential)</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-1">
            <span className="text-white font-bold block">Vandrevala Foundation (India)</span>
            <span className="text-indigo-300">Call: +91 9999 666 555 (24/7 Free)</span>
          </div>
        </div>
      </section>

      {/* Data Management & Deletion */}
      <section className="p-6 rounded-2xl bg-rose-950/20 border border-rose-900/30 space-y-4">
        <h2 className="text-base font-bold text-rose-200 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>Data Governance & Account Actions</span>
        </h2>

        <p className="text-xs text-slate-300 leading-relaxed">
          In alignment with the SIC MVP Product Specification, you have full sovereignty over your information.
        </p>

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            onClick={onExportData}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-700"
          >
            <Download className="w-4 h-4 text-indigo-400" />
            <span>Export Data (JSON)</span>
          </button>

          <button
            onClick={onClearAllConversations}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-900/50 text-slate-200 hover:text-rose-200 text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-700 hover:border-rose-700"
          >
            <RotateCcw className="w-4 h-4 text-rose-400" />
            <span>Clear All Conversations</span>
          </button>

          <button
            onClick={onPurgeAllMemories}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-900/50 text-slate-200 hover:text-rose-200 text-xs font-semibold flex items-center gap-2 transition-colors border border-slate-700 hover:border-rose-700"
          >
            <Brain className="w-4 h-4 text-rose-400" />
            <span>Purge All Memories</span>
          </button>

          <button
            onClick={onResetAllData}
            className="px-4 py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white text-xs font-semibold flex items-center gap-2 transition-all border border-rose-600/40"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Account & Reset Everything</span>
          </button>
        </div>
      </section>
    </div>
  );
};
