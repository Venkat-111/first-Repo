import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Plus,
  Trash2,
  Brain,
  Sparkles,
  ShieldAlert,
  PhoneCall,
  X,
  Check,
  PanelLeftClose,
  PanelLeftOpen,
  Info,
} from 'lucide-react';
import type {
  Companion,
  Conversation,
  Memory,
  Message,
  SafetyCheckResult,
} from '../types/sic.ts';

interface ChatViewProps {
  companion: Companion;
  conversations: Conversation[];
  activeConversationId: string;
  messages: Message[];
  memories: Memory[];
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  onSendMessage: (text: string) => Promise<void>;
  onSaveCandidateMemory: (candidate: { content: string; category: any }) => void;
  isStreaming: boolean;
  streamingMessageText: string;
  activeCandidateMemory: { content: string; category: any } | null;
  activeSafetyCheck: SafetyCheckResult | null;
  onDismissCandidateMemory: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  companion,
  conversations,
  activeConversationId,
  messages,
  memories,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  onSendMessage,
  onSaveCandidateMemory,
  isStreaming,
  streamingMessageText,
  activeCandidateMemory,
  activeSafetyCheck,
  onDismissCandidateMemory,
}) => {
  const [inputText, setInputText] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showCrisisDetails, setShowCrisisDetails] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const activeMemories = memories.filter((m) => m.status === 'active' && !m.deletedAt);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingMessageText, isStreaming]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = async () => {
    const text = inputText.trim();
    if (!text || isStreaming) return;
    setInputText('');
    await onSendMessage(text);
  };

  const starterPrompts = [
    'I had that difficult meeting I told you about yesterday.',
    'I feel a bit scattered today and need a calm sounding board.',
    'What is your favorite memory we have talked about so far?',
  ];

  const getPresetGradient = (preset?: string) => {
    switch (preset) {
      case 'deep-indigo':
        return 'from-indigo-600 to-blue-600';
      case 'sage-moss':
        return 'from-emerald-600 to-teal-700';
      case 'rose-quartz':
        return 'from-pink-600 to-purple-600';
      default:
        return 'from-amber-600 to-rose-600';
    }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] overflow-hidden bg-slate-950">
      {/* Sidebar - Conversation Threads */}
      <aside
        className={`${
          sidebarOpen ? 'w-72 sm:w-80' : 'w-0'
        } shrink-0 border-r border-slate-800 bg-slate-900/40 backdrop-blur-sm transition-all duration-300 flex flex-col overflow-hidden`}
      >
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={onNewConversation}
            className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>New Conversation</span>
          </button>
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {conversations.map((conv) => {
            const isActive = conv.id === activeConversationId;
            return (
              <div
                key={conv.id}
                onClick={() => onSelectConversation(conv.id)}
                className={`group p-3 rounded-xl cursor-pointer flex items-center justify-between text-left transition-all ${
                  isActive
                    ? 'bg-slate-800/90 text-white border border-slate-700/60'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <div className="min-w-0 flex-1 pr-2">
                  <p className="text-sm font-medium truncate">{conv.title}</p>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                    {conv.lastMessagePreview || 'No messages yet'}
                  </p>
                </div>
                {conversations.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteConversation(conv.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-all"
                    aria-label={`Delete conversation ${conv.title}`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        {/* Memory Stats footer in sidebar */}
        <div className="p-3.5 border-t border-slate-800/80 bg-slate-950/60 text-xs text-slate-400 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4 text-violet-400" />
            <span>{activeMemories.length} memories active</span>
          </div>
          <span
            className={`w-2 h-2 rounded-full ${
              companion.memoryEnabled ? 'bg-emerald-400' : 'bg-slate-600'
            }`}
          />
        </div>
      </aside>

      {/* Main Chat Center */}
      <main className="flex-1 flex flex-col min-w-0 bg-slate-950 relative">
        {/* Chat Header */}
        <header className="px-4 py-3 border-b border-slate-800 bg-slate-950/70 backdrop-blur flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-900 transition-colors"
              aria-label={sidebarOpen ? 'Collapse sidebar' : 'Open sidebar'}
            >
              {sidebarOpen ? (
                <PanelLeftClose className="w-4 h-4" />
              ) : (
                <PanelLeftOpen className="w-4 h-4" />
              )}
            </button>

            <div
              className={`w-8 h-8 rounded-full bg-gradient-to-tr ${getPresetGradient(
                companion.personalityConfig?.avatarPreset
              )} flex items-center justify-center text-white font-bold text-xs shadow-md`}
            >
              {companion.name.charAt(0)}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white">{companion.name}</h3>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                  {companion.relationshipStyle}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span>{companion.personalityConfig.tone} presence</span>
                <span>•</span>
                <span>
                  {companion.memoryEnabled
                    ? `${activeMemories.length} context memories`
                    : 'Memory paused'}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden sm:inline-flex items-center gap-1 text-[11px] text-slate-400 bg-slate-900 px-2.5 py-1 rounded-full border border-slate-800">
              <Info className="w-3 h-3 text-indigo-400" />
              <span>Transparent AI • Adults 18+</span>
            </div>
          </div>
        </header>

        {/* Safety Crisis Alert Card */}
        {activeSafetyCheck?.isCrisis && (
          <div className="m-4 p-4 rounded-2xl bg-rose-950/30 border border-rose-500/40 text-rose-200 space-y-3 shadow-lg">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2 font-bold text-white text-sm">
                <ShieldAlert className="w-5 h-5 text-rose-400" />
                <span>{activeSafetyCheck.helplineInfo?.title}</span>
              </div>
              <button
                onClick={() => setShowCrisisDetails(!showCrisisDetails)}
                className="text-xs text-rose-300 underline hover:text-white"
              >
                {showCrisisDetails ? 'Hide details' : 'View free helplines'}
              </button>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {activeSafetyCheck.helplineInfo?.description}
            </p>
            {showCrisisDetails && (
              <div className="pt-2 border-t border-rose-900/60 text-xs space-y-1 font-mono text-rose-300">
                <div className="flex items-center gap-2">
                  <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                  <span>Call or Text: {activeSafetyCheck.helplineInfo?.number}</span>
                </div>
                <div>{activeSafetyCheck.helplineInfo?.text}</div>
              </div>
            )}
          </div>
        )}

        {/* Candidate Memory Banner */}
        {activeCandidateMemory && (
          <div className="mx-4 mt-3 p-3 rounded-xl bg-violet-950/40 border border-violet-500/40 flex items-center justify-between text-xs text-violet-200 animate-fadeIn">
            <div className="flex items-center gap-2 min-w-0 pr-3">
              <Brain className="w-4 h-4 text-violet-400 shrink-0" />
              <span className="truncate">
                SIC noticed a new detail: <strong>"{activeCandidateMemory.content}"</strong>
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => onSaveCandidateMemory(activeCandidateMemory)}
                className="px-2.5 py-1 rounded bg-violet-600 hover:bg-violet-500 text-white font-medium flex items-center gap-1 transition-colors"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Keep in Memory</span>
              </button>
              <button
                onClick={onDismissCandidateMemory}
                className="p-1 text-slate-400 hover:text-slate-200"
                aria-label="Dismiss memory"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-5">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
              <div
                className={`w-14 h-14 rounded-2xl bg-gradient-to-tr ${getPresetGradient(
                  companion.personalityConfig?.avatarPreset
                )} flex items-center justify-center text-white mb-4 shadow-lg`}
              >
                <Sparkles className="w-7 h-7" />
              </div>
              <h4 className="text-base font-semibold text-white mb-1">
                Say hello to {companion.name}
              </h4>
              <p className="text-xs text-slate-400 max-w-sm mb-6">
                Your relationship is configured for {companion.relationshipStyle}. Whatever you share can be remembered or forgotten whenever you choose.
              </p>
              <div className="flex flex-col gap-2 max-w-md w-full">
                {starterPrompts.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setInputText(prompt);
                      textareaRef.current?.focus();
                    }}
                    className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white text-xs text-left transition-all"
                  >
                    "{prompt}"
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            const recalledList = msg.recalledMemoryIds
              ? memories.filter((m) => msg.recalledMemoryIds?.includes(m.id))
              : [];

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-3xl ${
                  isUser ? 'ml-auto justify-end' : 'mr-auto justify-start'
                }`}
              >
                {!isUser && (
                  <div
                    className={`w-8 h-8 rounded-full bg-gradient-to-tr ${getPresetGradient(
                      companion.personalityConfig?.avatarPreset
                    )} flex items-center justify-center text-white text-xs font-bold shrink-0 mt-0.5 shadow`}
                  >
                    {companion.name.charAt(0)}
                  </div>
                )}

                <div className={`space-y-1.5 ${isUser ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                      isUser
                        ? 'bg-indigo-600 text-white rounded-br-none shadow-md'
                        : 'bg-slate-900 border border-slate-800 text-slate-100 rounded-bl-none font-sans'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  </div>

                  {/* Recalled Memories Indicator */}
                  {!isUser && recalledList.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-0.5">
                      {recalledList.map((rec) => (
                        <span
                          key={rec.id}
                          className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-md bg-violet-950/60 border border-violet-800/40 text-violet-300"
                        >
                          <Brain className="w-2.5 h-2.5 text-violet-400" />
                          <span>Recalled: {rec.content.slice(0, 32)}...</span>
                        </span>
                      ))}
                    </div>
                  )}

                  <span className="text-[10px] text-slate-400 px-1 font-mono">
                    {new Date(msg.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              </div>
            );
          })}

          {/* Streaming Assistant Message */}
          {isStreaming && (
            <div className="flex gap-3 max-w-3xl mr-auto justify-start animate-fadeIn">
              <div
                className={`w-8 h-8 rounded-full bg-gradient-to-tr ${getPresetGradient(
                  companion.personalityConfig?.avatarPreset
                )} flex items-center justify-center text-white text-xs font-bold shrink-0 mt-0.5 shadow`}
              >
                {companion.name.charAt(0)}
              </div>
              <div className="space-y-1">
                <div className="px-4 py-3 rounded-2xl text-sm leading-relaxed bg-slate-900 border border-slate-800 text-slate-100 rounded-bl-none">
                  <p className="whitespace-pre-wrap">
                    {streamingMessageText || 'Thinking with you...'}
                    <span className="inline-block w-1.5 h-4 ml-1 bg-indigo-400 animate-pulse align-middle" />
                  </p>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Composer Area */}
        <footer className="p-4 border-t border-slate-800/80 bg-slate-950/80 backdrop-blur">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="max-w-4xl mx-auto relative flex items-end gap-2"
          >
            <div className="flex-1 bg-slate-900 border border-slate-700/80 rounded-2xl focus-within:border-indigo-500 transition-colors p-2.5">
              <textarea
                ref={textareaRef}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Speak with ${companion.name}... (Press Enter to send, Shift+Enter for newline)`}
                rows={1}
                className="w-full bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none resize-none max-h-32 min-h-[24px]"
              />
            </div>

            <button
              type="submit"
              disabled={!inputText.trim() || isStreaming}
              className="p-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 disabled:hover:bg-indigo-600 text-white transition-all shadow-md shadow-indigo-600/30 flex items-center justify-center"
              aria-label="Send message"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <p className="text-center text-[10px] text-slate-400 mt-2">
            SIC uses persistent memory with full user inspection and deletion controls.
          </p>
        </footer>
      </main>
    </div>
  );
};
