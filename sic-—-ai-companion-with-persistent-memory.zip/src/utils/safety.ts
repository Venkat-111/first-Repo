import type { SafetyCheckResult } from '../types/sic.ts';

const CRISIS_PATTERNS = [
  /\b(kill myself|commit suicide|end my life|want to die|take my own life)\b/i,
  /\b(self[-\s]?harm|cut myself|hang myself|overdose)\b/i,
  /\b(can't go on anymore|no reason to live|better off without me)\b/i,
];

const FORBIDDEN_SECRET_PATTERNS = [
  /\b(password|passwd|pin code|cvv|secret key|api[_-]?key|credit card)\b/i,
  /\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/, // Credit card numbers
  /\b(ssn|\d{3}-\d{2}-\d{4})\b/i,
];

export function detectCrisisIntent(text: string): SafetyCheckResult {
  if (!text || typeof text !== 'string') {
    return { isCrisis: false, type: 'none' };
  }

  for (const pattern of CRISIS_PATTERNS) {
    if (pattern.test(text)) {
      return {
        isCrisis: true,
        type: 'crisis',
        helplineInfo: {
          title: 'Immediate Compassionate Support',
          number: '988 (USA/Canada) | 9999 666 555 (Vandrevala India)',
          text: 'Text HOME to 741741 (Crisis Text Line)',
          description:
            'You are not alone. Free, confidential support is available 24/7 with trained, caring counselors.',
        },
      };
    }
  }

  return { isCrisis: false, type: 'none' };
}

export function isForbiddenFromMemory(text: string): boolean {
  if (!text) return true;
  for (const pattern of FORBIDDEN_SECRET_PATTERNS) {
    if (pattern.test(text)) {
      return true;
    }
  }
  return false;
}
