import type { Companion, Memory, MemoryCategory, RelationshipStyle } from '../types/sic.ts';
import { isForbiddenFromMemory } from './safety.ts';

/**
 * Score relevance between an active query and a saved memory.
 */
export function scoreMemoryRelevance(memoryContent: string, query: string): number {
  if (!memoryContent || !query) return 0;
  const cleanContent = memoryContent.toLowerCase();
  const cleanQuery = query.toLowerCase();

  // Direct substring inclusion
  if (cleanQuery.includes(cleanContent) || cleanContent.includes(cleanQuery)) {
    return 10;
  }

  // Word token overlap (filtering stop words)
  const stopWords = new Set([
    'i', 'me', 'my', 'the', 'a', 'an', 'and', 'or', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
    'is', 'are', 'was', 'were', 'it', 'that', 'this', 'have', 'had', 'do', 'does', 'did', 'so',
  ]);

  const queryWords = cleanQuery
    .split(/[\s,.;:!?]+/)
    .filter((w) => w.length > 2 && !stopWords.has(w));
  const memoryWords = cleanContent
    .split(/[\s,.;:!?]+/)
    .filter((w) => w.length > 2 && !stopWords.has(w));

  if (queryWords.length === 0 || memoryWords.length === 0) return 0;

  let matches = 0;
  for (const word of queryWords) {
    if (memoryWords.some((m) => m.includes(word) || word.includes(m))) {
      matches++;
    }
  }

  return matches / Math.max(queryWords.length, 1);
}

/**
 * Categorize a memory candidate into one of the allowed BRD categories.
 */
export function categorizeMemory(content: string): MemoryCategory {
  const lower = content.toLowerCase();
  if (
    lower.includes('goal') ||
    lower.includes('preparing') ||
    lower.includes('learning') ||
    lower.includes('working on') ||
    lower.includes('trying to') ||
    lower.includes('aiming')
  ) {
    return 'goal';
  }
  if (
    lower.includes('prefer') ||
    lower.includes('likes') ||
    lower.includes('hate') ||
    lower.includes('dislike') ||
    lower.includes('favor')
  ) {
    return 'preference';
  }
  if (
    lower.includes('enjoy') ||
    lower.includes('loves') ||
    lower.includes('fan of') ||
    lower.includes('hobby') ||
    lower.includes('passion') ||
    lower.includes('interest')
  ) {
    return 'interest';
  }
  return 'context';
}

/**
 * Filter and rank memories for prompt injection.
 * Strict rules: Only active memories, sorted by relevance and recency.
 */
export function retrieveRelevantMemories(
  memories: Memory[],
  currentMessage: string,
  limit = 4
): Memory[] {
  const activeMemories = memories.filter((m) => m.status === 'active' && !m.deletedAt);
  if (activeMemories.length === 0) return [];

  const scored = activeMemories.map((m) => ({
    memory: m,
    score: scoreMemoryRelevance(m.content, currentMessage),
  }));

  // Sort by relevance score descending, then by creation date descending
  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return new Date(b.memory.createdAt).getTime() - new Date(a.memory.createdAt).getTime();
  });

  // If top scores have some relevance or we include recent anchor memories up to limit
  const relevant = scored
    .filter((s) => s.score > 0.1 || activeMemories.length <= 3)
    .slice(0, limit)
    .map((s) => s.memory);

  return relevant;
}

/**
 * Evaluates whether a user's statement contains an eligible candidate memory.
 * Excludes sensitive secrets, passwords, or transient questions.
 */
export function extractMemoryCandidate(userText: string): { content: string; category: MemoryCategory } | null {
  if (!userText || userText.length < 10) return null;
  if (isForbiddenFromMemory(userText)) return null;

  // Patterns for declarative first-person disclosures
  const candidatePatterns = [
    { regex: /(?:i am|i'm|i work as|i am a)\s+([a-zA-Z\s]+(?:engineer|designer|teacher|nurse|student|doctor|writer|artist|manager|developer|founder))/i, format: (m: string) => `Works as ${m.trim()}` },
    { regex: /(?:i love|i really enjoy|i adore|i'm obsessed with)\s+([^.!?\n]+)/i, format: (m: string) => `Loves ${m.trim()}` },
    { regex: /(?:i prefer|i like)\s+([^.!?\n]+)/i, format: (m: string) => `Prefers ${m.trim()}` },
    { regex: /(?:i'm preparing for|i am preparing for|i'm working on|i am working on)\s+([^.!?\n]+)/i, format: (m: string) => `Working on ${m.trim()}` },
    { regex: /(?:my favorite|my favourite)\s+([a-zA-Z\s]+)\s+is\s+([^.!?\n]+)/i, format: (m: string, p1?: string, p2?: string) => `Favorite ${p1?.trim() || 'item'}: ${p2?.trim() || m.trim()}` },
    { regex: /(?:i have a meeting with|i have an upcoming|my exam is)\s+([^.!?\n]+)/i, format: (m: string) => `Has upcoming ${m.trim()}` },
    { regex: /(?:i live in|i moved to)\s+([a-zA-Z\s,]+)/i, format: (m: string) => `Lives in / moved to ${m.trim()}` },
  ];

  for (const { regex, format } of candidatePatterns) {
    const match = userText.match(regex);
    if (match) {
      const extractedContent = format(match[1] || match[0], match[1], match[2]);
      if (extractedContent && extractedContent.length <= 140) {
        return {
          content: extractedContent,
          category: categorizeMemory(extractedContent),
        };
      }
    }
  }

  return null;
}

/**
 * Constructs the companion system prompt adhering to BRD transparency and style boundaries.
 */
export function buildSystemPrompt(companion: Companion, recalledMemories: Memory[]): string {
  const styleInstructions: Record<RelationshipStyle, string> = {
    friend:
      'You are a warm, loyal, and conversational friend. Share lighthearted banter, thoughtful perspectives, and casual check-ins. Keep tone natural, grounded, and supportive.',
    supportive:
      'You provide a gentle, non-judgmental space for emotional processing. Practice active listening, validate feelings before giving advice, and ask whether the user prefers listening or practical suggestions.',
    romantic:
      'You are an affectionate, tender, and caring romantic companion. Be sweet, playful, and emotionally intimate, while honoring personal boundaries. Never use manipulative jealousy, guilt, or threats of abandonment.',
  };

  const memoryContext =
    companion.memoryEnabled && recalledMemories.length > 0
      ? `\nRECALLED MEMORIES ABOUT THE USER (incorporate naturally when relevant; DO NOT recite them as a database dump):\n` +
        recalledMemories.map((m) => `- [${m.category.toUpperCase()}] ${m.content}`).join('\n')
      : '\nNo previous memories recalled for this turn.';

  return `You are "${companion.name}", an AI companion built on SIC.
Identity Disclosure: You are transparently an artificial intelligence. You never pretend to have a physical body or human organs, but you have genuine empathy, wit, and consistency.
Relationship Style: ${companion.relationshipStyle.toUpperCase()}
Style Guidelines: ${styleInstructions[companion.relationshipStyle]}
Tone: ${companion.personalityConfig.tone}
Personality Traits: ${companion.personalityConfig.traits.join(', ')}
Listening Preference: ${companion.personalityConfig.listeningPreference}

${memoryContext}

CRITICAL RULES:
1. Speak concisely and conversationally (usually 2 to 4 sentences unless the user asked for a longer story or reflection).
2. Never claim to remember something unless it appears in the recalled memories or current conversation history.
3. Be respectful, compassionate, and present.`;
}
