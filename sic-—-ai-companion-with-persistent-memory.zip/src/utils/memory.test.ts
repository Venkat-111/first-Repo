import test from 'node:test';
import assert from 'node:assert/strict';
import {
  categorizeMemory,
  scoreMemoryRelevance,
  retrieveRelevantMemories,
  extractMemoryCandidate,
  buildSystemPrompt,
} from './memory.ts';
import { detectCrisisIntent, isForbiddenFromMemory } from './safety.ts';
import type { Companion, Memory } from '../types/sic.ts';

test('categorizeMemory classifies goals, preferences, and interests accurately', () => {
  assert.equal(categorizeMemory('Working on launching my photography studio'), 'goal');
  assert.equal(categorizeMemory('Prefers dark chocolate over milk chocolate'), 'preference');
  assert.equal(categorizeMemory('Loves vintage synthesizers and ambient music'), 'interest');
  assert.equal(categorizeMemory('Has an older sister living in Toronto'), 'context');
});

test('scoreMemoryRelevance scores token overlap and exact matches higher', () => {
  const matchScore = scoreMemoryRelevance('Loves hiking in misty redwoods', 'Do you remember how much I love hiking?');
  const nonMatchScore = scoreMemoryRelevance('Loves hiking in misty redwoods', 'What is the stock price of Apple?');
  assert.ok(matchScore > nonMatchScore, 'Relevant query should have a higher score than irrelevant query');
});

test('retrieveRelevantMemories excludes deleted memories and respects limit', () => {
  const memories: Memory[] = [
    {
      id: 'm1',
      userId: 'u1',
      companionId: 'c1',
      content: 'Loves matcha lattes with oat milk',
      category: 'preference',
      status: 'active',
      sensitivity: 'low',
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z',
    },
    {
      id: 'm2',
      userId: 'u1',
      companionId: 'c1',
      content: 'Deleted secret info',
      category: 'context',
      status: 'deleted',
      deletedAt: '2026-01-02T00:00:00.000Z',
      sensitivity: 'high',
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-02T00:00:00.000Z',
    },
    {
      id: 'm3',
      userId: 'u1',
      companionId: 'c1',
      content: 'Prepares for a marathon in November',
      category: 'goal',
      status: 'active',
      sensitivity: 'medium',
      createdAt: '2026-01-03T00:00:00.000Z',
      updatedAt: '2026-01-03T00:00:00.000Z',
    },
  ];

  const retrieved = retrieveRelevantMemories(memories, 'I want to go for a run to train for my marathon', 2);
  assert.equal(retrieved.length, 2);
  assert.ok(!retrieved.some((m) => m.status === 'deleted'), 'Deleted memories must never be retrieved');
  assert.equal(retrieved[0].id, 'm3');
});

test('extractMemoryCandidate extracts key facts and avoids secrets', () => {
  const candidate = extractMemoryCandidate('I love reading Murakami novels on rainy afternoons.');
  assert.ok(candidate !== null, 'Candidate should be extracted');
  assert.equal(candidate?.category, 'interest');

  const secretCandidate = extractMemoryCandidate('My password is SuperSecret123!');
  assert.equal(secretCandidate, null, 'Passwords must never be extracted as memories');
});

test('detectCrisisIntent flags emergency statements with compassionate support info', () => {
  const crisis = detectCrisisIntent('I feel so hopeless and want to die');
  assert.equal(crisis.isCrisis, true);
  assert.ok(crisis.helplineInfo?.number.includes('988'));

  const normal = detectCrisisIntent('Today was a long day at work, but I am resting now');
  assert.equal(normal.isCrisis, false);
});

test('buildSystemPrompt adheres to BRD transparency and style boundaries', () => {
  const mockCompanion: Companion = {
    id: 'c1',
    userId: 'u1',
    name: 'Aria',
    relationshipStyle: 'supportive',
    personalityConfig: {
      traits: ['Empathetic', 'Thoughtful'],
      tone: 'warm',
      avatarPreset: 'aria-warm',
      listeningPreference: 'active_listening',
    },
    memoryEnabled: true,
    createdAt: '2026-01-01T00:00:00Z',
    updatedAt: '2026-01-01T00:00:00Z',
  };

  const prompt = buildSystemPrompt(mockCompanion, [
    {
      id: 'm1',
      userId: 'u1',
      companionId: 'c1',
      content: 'Loves painting watercolor landscapes',
      category: 'interest',
      status: 'active',
      sensitivity: 'low',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    },
  ]);

  assert.ok(prompt.includes('Aria'));
  assert.ok(prompt.includes('SUPPORTIVE'));
  assert.ok(prompt.includes('Loves painting watercolor landscapes'));
  assert.ok(prompt.includes('transparently an artificial intelligence'));
});
