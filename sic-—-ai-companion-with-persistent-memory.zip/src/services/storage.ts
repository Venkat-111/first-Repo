import type {
  Companion,
  Conversation,
  Memory,
  Message,
  UserProfile,
} from '../types/sic.ts';

const STORAGE_KEYS = {
  PROFILE: 'sic_user_profile_v1',
  COMPANION: 'sic_companion_v1',
  CONVERSATIONS: 'sic_conversations_v1',
  MESSAGES: 'sic_messages_v1',
  MEMORIES: 'sic_memories_v1',
};

const DEFAULT_PROFILE: UserProfile = {
  id: 'usr-default-01',
  displayName: 'Alex',
  email: 'alex@example.com',
  ageConfirmed: true,
  ageConfirmedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  updatedAt: new Date().toISOString(),
};

const DEFAULT_COMPANION: Companion = {
  id: 'comp-default-01',
  userId: 'usr-default-01',
  name: 'Aria',
  relationshipStyle: 'supportive',
  personalityConfig: {
    traits: ['Empathetic', 'Thoughtful', 'Calm', 'Attentive'],
    tone: 'warm',
    avatarPreset: 'warm-ember',
    listeningPreference: 'active_listening',
  },
  memoryEnabled: true,
  createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  updatedAt: new Date().toISOString(),
};

const DEFAULT_MEMORIES: Memory[] = [
  {
    id: 'mem-01',
    userId: 'usr-default-01',
    companionId: 'comp-default-01',
    content: 'Prefers quiet mornings and drinking ceremonial matcha before work',
    category: 'preference',
    status: 'active',
    sensitivity: 'low',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'mem-02',
    userId: 'usr-default-01',
    companionId: 'comp-default-01',
    content: 'Loves architectural photography and vintage Leica cameras',
    category: 'interest',
    status: 'active',
    sensitivity: 'low',
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
  {
    id: 'mem-03',
    userId: 'usr-default-01',
    companionId: 'comp-default-01',
    content: 'Working on finishing a personal design portfolio by end of month',
    category: 'goal',
    status: 'active',
    sensitivity: 'medium',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
];

const DEFAULT_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-01',
    userId: 'usr-default-01',
    companionId: 'comp-default-01',
    title: 'Morning check-in & portfolio goals',
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    lastMessagePreview: "Take it one step at a time today. You're doing meaningful work.",
    messageCount: 4,
  },
];

const DEFAULT_MESSAGES: Record<string, Message[]> = {
  'conv-01': [
    {
      id: 'msg-01',
      conversationId: 'conv-01',
      userId: 'usr-default-01',
      role: 'assistant',
      content:
        "Good morning, Alex. I made sure to leave space for you today. How are you feeling as you step into your morning?",
      status: 'complete',
      createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    },
    {
      id: 'msg-02',
      conversationId: 'conv-01',
      userId: 'usr-default-01',
      role: 'user',
      content:
        "I'm feeling a bit anxious about the design portfolio deadline, but I made my matcha and sat down.",
      status: 'complete',
      createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
      recalledMemoryIds: ['mem-01', 'mem-03'],
    },
    {
      id: 'msg-03',
      conversationId: 'conv-01',
      userId: 'usr-default-01',
      role: 'assistant',
      content:
        "Having that calm matcha ritual first is such a grounding anchor. Remember, a portfolio doesn't need to showcase every single thing you've ever done—just the work that speaks to the designer you are becoming. Would you like to break today's task into two gentle chunks?",
      status: 'complete',
      createdAt: new Date(Date.now() - 3600000 * 4.9).toISOString(),
      recalledMemoryIds: ['mem-01', 'mem-03'],
    },
    {
      id: 'msg-04',
      conversationId: 'conv-01',
      userId: 'usr-default-01',
      role: 'user',
      content: "Yes, that sounds so much better than staring at a giant blank checklist.",
      status: 'complete',
      createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    },
  ],
};

export class StorageService {
  static getProfile(): UserProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : DEFAULT_PROFILE;
    } catch {
      return DEFAULT_PROFILE;
    }
  }

  static saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.warn('Storage saveProfile error', e);
    }
  }

  static getCompanion(): Companion {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.COMPANION);
      return data ? JSON.parse(data) : DEFAULT_COMPANION;
    } catch {
      return DEFAULT_COMPANION;
    }
  }

  static saveCompanion(companion: Companion): void {
    try {
      localStorage.setItem(STORAGE_KEYS.COMPANION, JSON.stringify(companion));
    } catch (e) {
      console.warn('Storage saveCompanion error', e);
    }
  }

  static getConversations(): Conversation[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CONVERSATIONS);
      return data ? JSON.parse(data) : DEFAULT_CONVERSATIONS;
    } catch {
      return DEFAULT_CONVERSATIONS;
    }
  }

  static saveConversations(convs: Conversation[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CONVERSATIONS, JSON.stringify(convs));
    } catch (e) {
      console.warn('Storage saveConversations error', e);
    }
  }

  static getMessages(conversationId: string): Message[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      const all: Record<string, Message[]> = data ? JSON.parse(data) : DEFAULT_MESSAGES;
      return all[conversationId] || [];
    } catch {
      return DEFAULT_MESSAGES[conversationId] || [];
    }
  }

  static saveMessages(conversationId: string, msgs: Message[]): void {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      const all: Record<string, Message[]> = data ? JSON.parse(data) : DEFAULT_MESSAGES;
      all[conversationId] = msgs;
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(all));
    } catch (e) {
      console.warn('Storage saveMessages error', e);
    }
  }

  static getMemories(): Memory[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MEMORIES);
      return data ? JSON.parse(data) : DEFAULT_MEMORIES;
    } catch {
      return DEFAULT_MEMORIES;
    }
  }

  static saveMemories(memories: Memory[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.MEMORIES, JSON.stringify(memories));
    } catch (e) {
      console.warn('Storage saveMemories error', e);
    }
  }

  static resetAll(): void {
    try {
      localStorage.removeItem(STORAGE_KEYS.PROFILE);
      localStorage.removeItem(STORAGE_KEYS.COMPANION);
      localStorage.removeItem(STORAGE_KEYS.CONVERSATIONS);
      localStorage.removeItem(STORAGE_KEYS.MESSAGES);
      localStorage.removeItem(STORAGE_KEYS.MEMORIES);
    } catch (e) {
      console.warn('Storage resetAll error', e);
    }
  }
}
